PERSMAP / PRESS KIT / DOSSIER DE PRESSE — allesgut
============================================================

Persbericht / press release / communiqué: persbericht-allesgut-bjorn-wandels-en.pdf, persbericht-allesgut-bjorn-wandels-fr.pdf, persbericht-allesgut-bjorn-wandels-nl.pdf
Beelden / images / visuels: map beelden/

Alle beelden: © 2026 Björn Wandels. Courtesy de kunstenaar en DeNode Foundation, Gent.

NL — Vrij te gebruiken voor berichtgeving over de tentoonstelling allesgut (DeNode Foundation, 11.09 – 04.10.2026), met vermelding © Björn Wandels. Niet bijsnijden of bewerken zonder toestemming.
EN — Free to use for coverage of the exhibition allesgut (DeNode Foundation, 11.09 – 04.10.2026), with the credit © Björn Wandels. Please do not crop or alter without permission.
FR — Libre d'utilisation pour la couverture de l'exposition allesgut (DeNode Foundation, 11.09 – 04.10.2026), avec la mention © Björn Wandels. Ne pas recadrer ni retoucher sans autorisation.

Bijschriften / Captions / Légendes:
- allesgut-01-logo.jpg — NL: allesgut — logo (stempel) · EN: allesgut — logo (stamp) · FR: allesgut — logo (tampon) · 1332 × 1820 px (11.3 × 15.4 cm @ 300 dpi) · © 2026 Björn Wandels
- allesgut-02-paars-silhouet.jpg — NL: allesgut — paars silhouet · EN: allesgut — purple silhouette · FR: allesgut — silhouette violette · 2599 × 3674 px (22.0 × 31.1 cm @ 300 dpi) · © 2026 Björn Wandels
- allesgut-03-figuur-in-stoel.jpg — NL: allesgut — figuur in stoel · EN: allesgut — figure in a chair · FR: allesgut — figure dans un fauteuil · 2599 × 3674 px (22.0 × 31.1 cm @ 300 dpi) · © 2026 Björn Wandels
- allesgut-04-cover.jpg — NL: allesgut — cover van het kunstenaarsboek (MER Books, 2026) · EN: allesgut — cover of the artist's book (MER Books, 2026) · FR: allesgut — couverture du livre d'artiste (MER Books, 2026) · 2599 × 3674 px (22.0 × 31.1 cm @ 300 dpi) · © 2026 Björn Wandels
- allesgut-05-naakt-en-rode-stoel.jpg — NL: allesgut — naakt en rode stoel (spread) · EN: allesgut — nude and red chair (spread) · FR: allesgut — nu et chaise rouge (double page) · 5197 × 3674 px (44.0 × 31.1 cm @ 300 dpi) · © 2026 Björn Wandels
- allesgut-06-bloemen-en-figuur.jpg — NL: allesgut — bloemen en figuur (spread) · EN: allesgut — flowers and figure (spread) · FR: allesgut — fleurs et figure (double page) · 5197 × 3674 px (44.0 × 31.1 cm @ 300 dpi) · © 2026 Björn Wandels
- allesgut-07-gesplitst-gezicht.jpg — NL: allesgut — gesplitst gezicht · EN: allesgut — split face · FR: allesgut — visage scindé · 2599 × 3674 px (22.0 × 31.1 cm @ 300 dpi) · © 2026 Björn Wandels
- allesgut-08-gezicht-in-licht.jpg — NL: allesgut — gezicht in licht · EN: allesgut — face in light · FR: allesgut — visage dans la lumière · 2599 × 3674 px (22.0 × 31.1 cm @ 300 dpi) · © 2026 Björn Wandels
- allesgut-09-konijnenoren.jpg — NL: allesgut — figuren met konijnenoren (spread) · EN: allesgut — figures with rabbit ears (spread) · FR: allesgut — figures aux oreilles de lapin (double page) · 5197 × 3674 px (44.0 × 31.1 cm @ 300 dpi) · © 2026 Björn Wandels
- denode-foundation-logo.png — NL: DeNode Foundation — logo (zwart, transparant) · EN: DeNode Foundation — logo (black, transparent) · FR: DeNode Foundation — logo (noir, transparent) · 1808 × 1036 px (15.3 × 8.8 cm @ 300 dpi) · © Stichting DeNode

Perscontact / Press contact / Contact presse: Kristof Vander Cruyssen — kristof@denode.be — +32 488 88 08 89
Stichting DeNode · Galerie DeNode — nodenaysteen · Predikherenlei 4, 9000 Gent · denode.be

Samengesteld / compiled 2026-09-06.